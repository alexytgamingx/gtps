require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6285389296108"
global.namaowner = "kinchan"
global.namaowner2 = "kinchan"

//======== Setting Bot & Link ========//
global.namabot = "cremoxz" 
global.namabot2 = "cremoxz"
global.idsaluran = "https://chat.whatsapp.com/BvFClrzWjSX8DO18FUHb0S"
global.linkgc = 'https://chat.whatsapp.com/BvFClrzWjSX8DO18FUHb0S'
global.linkgc2 = "https://chat.whatsapp.com/BvFClrzWjSX8DO18FUHb0S"
global.linksaluran = "https://chat.whatsapp.com/BvFClrzWjSX8DO18FUHb0S"
global.linkyt = 'https://chat.whatsapp.com/BvFClrzWjSX8DO18FUHb0S'
global.packname = "Created By Kinchan"

//========== Setting Event ==========//
global.autoread = false
global.anticall = false
global.autoreadsw = false
global.owneroff = false
global.autopromosi = true

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 5500
global.delayjpm = 5500

//========== Setting Foto ===========//
global.imgreply = "https://autoresbot.com/tmp_files/3f586b52-9379-43f1-aa74-883e9dd43fab.jpg"
global.imgmenu = fs.readFileSync("./media/Menu.jpg")
global.imgmenu2 = fs.readFileSync("./media/Menu2.jpg")
global.imgbug = fs.readFileSync("./media/Bug.jpg")
global.imgslide = "https://autoresbot.com/tmp_files/3f586b52-9379-43f1-aa74-883e9dd43fab.jpg"
global.imgpanel = fs.readFileSync("./media/Panel.jpg")


//========== Setting Panell ==========//
global.egg = "15"
global.nestid = "6"
global.loc = "1"
global.domain = "https://skyzo.my.id"
global.apikey = "ptla_5iLKDhKvGTMCM262JK0C32xVD7EQ1OZIF17SSpIkvep" //ptla
global.capikey = "ptlc_Y95PPHsduh06e16Y5DjTPj537bpfquJUQUHE8klSg1c" //ptlc

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi "Gak Ada"
global.dana = "088706060787"
global.gopay = "081545621997"
global.ovo = "081545621997"
global.qris = "https://autoresbot.com/tmp_files/f571d461-e9c6-451a-bc2a-03e2cece1e6d.jpg"
                             
//=========== Api Domain ===========//
global.subdomain = {
"digitalserver.biz.id": {
"zone": "c2047082b74a80e5be03959bad59592a", 
"apitoken": "SDG2MrxgoJLZ8GDkpWk2PalEn-Vg8PQkjEsPQ_Wy"
}, 
"skyzo.my.id": {
"zone": "9de948bb1589175a8c9353612759b678", 
"apitoken": "poNl1SWzhD3rCUqFwfXwK7iAm2SobqeyLFJWa9nB"
}, 
"tokopanellku.my.id": {
"zone": "5f4a582dd80c518fb2c7a425256fb491", 
"apitoken": "iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby"
}, 
"panellstore.net": {
"zone": "d41a17e101c0f89f0aec609c31137f91", 
"apitoken": "miC4wpso1vMcRFR62ZvOFfFd9xTlawvHcXPYZgwi"
}
}


//========= Setting Message =========//
global.msg = {
"error": "Error terjasi kesalahan",
"done": "Done Bang ✅", 
"wait": "⏳Memproses . . .", 
"group": "Command Ini Hanya Untuk Didalam Grup", 
"private": "Command Ini Hanya Untuk Di Private Chat", 
"admin": "Command Ini Hanya Untuk Admin Grup", 
"adminbot": "Command Ini Dapat Di Gunakan Ketika Bot Menjadi Admin", 
"owner": "Maaf Command Ini Hanya Untuk Owner Bot", 
"developer": "Command Ini Hanya Untuk Developer Bot!"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})